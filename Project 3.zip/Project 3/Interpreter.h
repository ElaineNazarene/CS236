#ifndef INTERPRETER_H
#define INTERPRETER_H

#include "Header.h"
#include "Database.h"
#include "datalogProgram.h"
class Interpreter{
private:
    DatalogProgram program;
    Database database;
public:

    Interpreter(DatalogProgram program) : program(program) {}

    void run(){
        
        Interpret_Schemes();

     
        Interpret_Facts();

      
        Interpret_Queries();

    }

    void Interpret_Schemes(){
     
        vector<Predicate> scheme_to_go_through = program.Get_Schemes();

        for (Predicate scheme : scheme_to_go_through) { 
            Header header; 

            vector <Parameter> scheme_parameters = scheme.Get_Parameters();
            for (Parameter p : scheme_parameters) {
                string currHeader = p.Get_ID();
                header.Add_Header(currHeader); 
            }

            string currRelation= scheme.Get_ID();
            database.Add_Relation(currRelation, header); 
        }
    }

    void Interpret_Facts() {
        
        vector <Predicate> rows_to_go_through = program.Get_Facts();

        for (Predicate fact : rows_to_go_through) {
            Tuple tuple; 

            vector <Parameter> tuple_parameters_to_go_through = fact.Get_Parameters();
            for (Parameter p : tuple_parameters_to_go_through) {

            
                string currTuple = p.Get_ID();
                tuple.Add_TupleValue(currTuple); 
            }

            string currRow = fact.Get_ID();
            database.Add_Tuple(currRow, tuple);
        }
    }

    void Interpret_Queries() {
      

        vector <Predicate> queries_to_go_through = program.Get_Queries();
        int size_of_queries = queries_to_go_through.size();
        for (unsigned int i = 0; i < size_of_queries; i++) { 

            Predicate currQuery = queries_to_go_through.at(i);
            cout << currQuery.toString() << "?";

           
            Relation output = Interpret_Predicate(currQuery);

            int output_size = output.Get_Size();

            if (output_size == 0) { 
                cout << " " << "No" << endl;
            } else { 
                cout << " " << "Yes(" << output_size << ")" << endl;
            }

            cout << output.toString();
        }
    }

    Relation Interpret_Predicate (Predicate predicate) {
        
        string pred_ID = predicate.Get_ID(); 
        Relation output = database.Get_Relation(pred_ID); 

        map<string, unsigned int> seen;
        string seen_Values = "";

    
        vector<int> unseen_Columns; 
        vector<string> unseen_Headers; 

        unsigned int col_position = 0; 

        vector<Parameter> tuple_in_predicate = predicate.Get_Parameters();

       
        for (Parameter parameter : tuple_in_predicate) { 
            string currParameter = parameter.Get_ID(); 

            if (parameter.isConstant()) { 
                output = output.select(col_position, currParameter);    

            } else { 
                if (seen.find(currParameter) != seen.end()) {
                    output = output.select(col_position, seen.at(currParameter));   
                
                } else {
                    seen.insert({currParameter, col_position});
                    unseen_Columns.push_back(col_position);
                    unseen_Headers.push_back(currParameter);
                }
            }
            col_position++;
        }

      
        output = output.project(unseen_Columns); 
      
        output = output.rename(unseen_Headers); 

        return output;
    }


};
#endif //INTERPRETER_H
