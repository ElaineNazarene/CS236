
#ifndef COMMAAUTOMATON_H
#define COMMAAUTOMATON_H

#include "Automaton.h"



class CommaAutomaton : public Automaton
{
public:
    CommaAutomaton() : Automaton(TokenType::COMMA) {} 

    void S0(const std::string& input){
        if (input[index] == ',') {
            inputRead = 1;
        }
    }
};


#endif //COMMAAUTOMATON_H
