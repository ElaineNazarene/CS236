#include "FactsAutomaton.h"

void FactsAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('F')) {
        Accept();
        S1(input);
    }
}

void FactsAutomaton::S1(const std::string& input) {
    if (Match('a')) {
        Accept();
        S2(input);
    } else {
        Serr();
    }
}

void FactsAutomaton::S2(const std::string& input) {
    if (Match('c')) {
        Accept();
        S3(input);
    } else {
        Serr();
    }
}

void FactsAutomaton::S3(const std::string& input) {
    if (Match('t')) {
        Accept();
        S4(input);
    } else {
        Serr();
    }
}

void FactsAutomaton::S4(const std::string& input) {
    if (Match('s')) {
        Accept();
    } else {
        Serr();
    }
}
