#include "QueriesAutomaton.h"

void QueriesAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('Q')) {
        Accept();
        S1(input);
    } else {
        Serr();
    }
}

void QueriesAutomaton::S1(const std::string& input) {
    if (Match('u')) {
        Accept();
        S2(input);
    } else {
        Serr();
    }
}

void QueriesAutomaton::S2(const std::string& input) {
    if (Match('e')) {
        Accept();
        S3(input);
    } else {
        Serr();
    }
}

void QueriesAutomaton::S3(const std::string& input) {
    if (Match('r')) {
        Accept();
        S4(input);
    } else {
        Serr();
    }
}

void QueriesAutomaton::S4(const std::string& input) {
    if (Match('i')) {
        Accept();
        S5(input);
    } else {
        Serr();
    }
}

void QueriesAutomaton::S5(const std::string& input) {
    if (Match('e')) {
        Accept();
        S6(input);
    } else {
        Serr();
    }
}

void QueriesAutomaton::S6(const std::string& input) {
    if (Match('s')) {
        Accept();
    } else {
        Serr();
    }
}
