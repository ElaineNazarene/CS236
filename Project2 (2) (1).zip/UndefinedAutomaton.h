//
// Created by abrah on 04/10/2022.
//

#ifndef PROJECT1_LEXER_UNDEFINEDAUTOMATON_H
#define PROJECT1_LEXER_UNDEFINEDAUTOMATON_H

#include "Automaton.h"

class UndefinedAutomaton : public Automaton {

    void S0() override
    {
        if (EndOfFile())
        {
            Serr();
        }
        else
            Accept();
    }

public:
    UndefinedAutomaton() : Automaton(TokenType::UNDEFINED) {}
};

#endif //PROJECT1_LEXER_UNDEFINEDAUTOMATON_H
