#ifndef DATALOGPROGRAM_H
#define DATALOGPROGRAM_H

#include <vector>
#include <set>
#include <sstream>

#include "Predicate.h"
#include "Parameter.h"
#include "Rule.h"
#include "Token.h"
using namespace std;

class DatalogProgram {
private:
   
    vector<Predicate> schemes; 
    vector<Predicate> facts; 
    vector<Predicate> queries; 
    vector<Rule> rules; 
    set<string> Domains; 

public:

    void push_Schemes(Predicate scheme){
        schemes.push_back(scheme);
    }
    void push_Facts(Predicate fact){
        facts.push_back(fact);
    }
    void push_Queries(Predicate query){
        queries.push_back(query);
    }
    void push_Rules(Rule rule){
        rules.push_back(rule);
    }
    void push_Domain(string domain){
        Domains.insert(domain);
    }

  


    vector<Predicate> Get_Schemes() {
        return DatalogProgram::schemes;
    }

  
    vector<Predicate> Get_Facts() {
        return DatalogProgram::facts;
    }


    vector<Rule> Get_Rules() {
        return DatalogProgram::rules;
    }


    vector<Predicate> Get_Queries() {
        return DatalogProgram::queries;
    }



    string toString() {

        stringstream out;
     
        out << "Schemes(" << schemes.size() << "):" << endl;
        for (Predicate scheme : schemes) {
            out << "  " << scheme.toString() << endl;
        }


        out << "Facts(" << facts.size() << "):" << endl;
        for (Predicate fact : facts) {
            out << "  " << fact.toString() << "." << endl;
        }

     
        out << "Rules(" << rules.size() << "):" << endl;
        for (Rule rule : rules) {
            out << "  " << rule.toString() << "." << endl;
        }


        out << "Queries(" << queries.size() << "):" << endl;
        for (Predicate query : queries) {
            out << "  " << query.toString() << "?" << endl;
        }

   
        out << "Domain(" << Domains.size() << "):" << endl;
        for (std::string s : Domains) {
            out << "  " << s << endl;
        }

        return out.str();
    }

};


#endif //DATALOGPROGRAM_H
