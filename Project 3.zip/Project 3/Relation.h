#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <set>

#include "Header.h"
#include "Tuple.h"

using namespace std;

#ifndef PROJECT_1_RELATION_H
#define PROJECT_1_RELATION_H
class Relation{
private:
    string name;
    Header header;
    set<Tuple> tuples;
public:

    Relation() = default;
    Relation(string name, Header header) : name(name), header(header) {}


    string Get_Name() {
        return name;
    }
    int Get_Size() {
        return tuples.size();
    }


    void Set_Tuples(set<Tuple> tuples) {
        this->tuples = tuples;
    }


    void Add_Tuple(Tuple t) {
        tuples.insert(t);
    }

    
    string toString() {
        stringstream o;
        for (Tuple t : tuples) {
            if (t.size() > 0) {
                o << " " << t.toString(header) << endl;
            }
           
        }

        return o.str();
    }

    Relation select(int position, string value) {
       
        Relation output(name, header); 
        Tuple tuple;

       
        for (Tuple tuple : tuples) { 
          
            string selected_tuple_value = tuple.Get_TupleValue(position);
            if (selected_tuple_value == value) {
                output.Add_Tuple(tuple); 

            }
        }
        return output; 
    }

    Relation select(int position1, int position2) {
       

        Relation output(name, header); 

      
        if (position1 >= header.size() || position2 >= header.size()){ 
            throw "out of bound"; 
        }

        for (Tuple tuple : tuples) { 
            if (tuple.Get_TupleValue(position1) == tuple.Get_TupleValue(position2)) { 
                output.Add_Tuple(tuple); 
            }
        }

        return output; 
    }

    Relation project(vector<int> columnsToProject) { 
        Header new_Header; 

        
        int column_to_parse_through = columnsToProject.size();
        for (unsigned int i = 0; i < column_to_parse_through; i++) {
            string currHeader = header.Find_Header(i); 
            new_Header.Add_Header(currHeader);
        }

        Relation output(name, new_Header);

        

        for (auto tuple : tuples) { 
            Tuple new_Tuple; 

            for (auto i : columnsToProject) {
                string currTuple = tuple.Get_TupleValue(i);
                new_Tuple.Add_TupleValue(currTuple);
            }

            output.Add_Tuple(new_Tuple);
        }

        return output;
    }

    Relation rename(vector<string> header) {
       
        Header new_header(header); 

        Relation output(name, new_header);
        output.Set_Tuples(tuples);

        return output;
    }

    bool isJoinable(){
      
        return true;
    }

};
#endif //PROJECT_1_RELATION_H
