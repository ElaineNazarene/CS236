#ifndef PREDICATE_H
#define PREDICATE_H
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

using namespace std;

class Predicate
{
private:
    string Name;
    vector<string> Values;

public:
    string getName()
    {
        return this->Name;
    }

    void setName(string Name)
    {
        this->Name = Name;
    }

    vector<string> getValues()
    {
        return this->Values;
    }

    void setValues(vector<string> Values)
    {
        this->Values = Values;
    }

    void AddValue(string value)
    {
        Values.push_back(value);
    }

    Predicate(){

    }

    string toString()
    {
        stringstream ss;

        ss << Name << "(";

        for (unsigned int i = 0; i < Values.size() - 1; i++)
        {
            ss << Values.at(i) << ", ";
        }
        ss << Values.at(Values.size() - 1) << ")";
        return ss.str();
    }
};

#endif