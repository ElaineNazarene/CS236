#include "ColonAutomaton.h"

void ColonAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match(':')) {
        Accept();
    } 
}