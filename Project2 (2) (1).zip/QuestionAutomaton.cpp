#include "QuestionAutomaton.h"

void QuestionAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('?')) {
        Accept();
    } 
}
