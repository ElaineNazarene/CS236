#ifndef PREDICATE_H
#define PREDICATE_H
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include "Parameter.h"

using namespace std;

class Predicate {
private:
    vector<Parameter> parameters;
    string pred_id;


public:

    void Add_Parameter(Parameter p) {
        parameters.push_back(p);
    }


    void Set_ID(string ID) {
        pred_id = ID;
    }


    string Get_ID(){
        return pred_id;
    }
    vector<Parameter> Get_Parameters() {
        return parameters;
    }


    string toString() {
        stringstream out;

        string seperate = "";
        out << pred_id << "("; 
        for (Parameter currParam: parameters) {
            out << seperate << currParam.toString();
            seperate = ",";
        }
        out << ")";

        return out.str();

    
    }
};
#endif //PREDICATE_H