#include "Token.h"
#include "sstream"

using namespace std;


Token::Token(TokenType type, std::string description, unsigned int line) {
    this->type = type;
    this->description = description;
    this->line = line;
}



string Token::ConvertToken(TokenType tokenType) {
    switch(tokenType) {
    case TokenType::COMMA:
        return "COMMA";
    case TokenType::COLON:
        return "COLON";;
    case TokenType::COLON_DASH:
        return "COLON_DASH";
    case TokenType::MULTIPLY:
        return "MULTIPLY";
    case TokenType::PERIOD:
        return "PERIOD";
    case TokenType::QUESTION:
        return "Q_MARK";
    case TokenType::ADD:
        return "ADD";
    case TokenType::RIGHT_PAREN:
        return "RIGHT_PAREN";
    case TokenType::LEFT_PAREN: 
        return "LEFT_PAREN";
    case TokenType::SCHEMES:
        return "SCHEMES";
    case TokenType::QUERIES:
        return "QUERIES";
    case TokenType::FACTS:
        return "FACTS";
    case TokenType::RULES:
        return "RULES";
    case TokenType::ID:
        return "ID";
    case TokenType::COMMENT:
        return "COMMENT";
    case TokenType::STRING:
        return "STRING";;
    case TokenType::UNDEFINED:
        return "UNDEFINED";
    case TokenType::ENDFILE:
        return "EOF";
    default: return "Read Error";
    }
}



std::string Token::toString() {
    std::stringstream out;

    out << "(" << ConvertToken(type) << "," << "\"" << description <<"\"" << "," << line << ")";
    
    return out.str();
}