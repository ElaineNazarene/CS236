
#ifndef STRINGAUTOMATON_H
#define STRINGAUTOMATON_H

#include <iostream>
#include <sstream>
#include "Automaton.h"
using namespace std;

class StringAutomaton : public Automaton {
public:
    StringAutomaton() : Automaton(TokenType::STRING){}

    void S0(const string& input) {
        multilineInc = 0; 
        if (input[index] == '\'') { 
            inputRead++;
            index++;
            S1(input);
        } else {
            Serr();
        }
    }


    void S1(const string& input){
        size_t sizeOfString = input.size();
        if (index >= sizeOfString) { 
            endFlag = true;
            return;
        } else if (input[index] == '\'') { 
            Continue();
            S2(input); 
        } else {

            if (input.at(inputRead) == '\n') {
                hasMultiline = true;
                multilineInc++;
            }
            Continue();
            S1(input); 
        }
        
    }

    void S2(const string& input) {
        if (input[index] == '\'') { 
            Continue();
            S1(input); 
        } else {
            return; 
        }
    }
};
#endif //STRINGAUTOMATON_H

