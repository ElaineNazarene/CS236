#ifndef AUTOMATON_H
#define AUTOMATON_H
#include "Token.h"
#include <stdexcept>
using namespace std;
class Automaton
{
protected:
    unsigned int newLines = 0;
    unsigned int index = 0;
    unsigned int input_read = 0;
    TokenType type = UNDEFINED;
    string input;

    virtual void S0() = 0;

    void Accept()
    {
        if (CurrentLetter() == '\n')
        {
            newLines++;
        }
        index++;
        input_read++;
    }

    char CurrentLetter()
    {
        if (EndOfFile())
        {
            throw out_of_range(Token::ConvertToken(type) + "CURRENT: Tried to read past file");
        }
        return input.at(index);
    }

    bool Match(char c)
    {
        if (EndOfFile())
        {
            throw out_of_range(Token::ConvertToken(type) + "MATCH: Tried to read past file");
        }
        return (CurrentLetter() == c);
    }

    bool EndOfFile()
    {
        return (index >= input.size());
    }


    // Every subclass must define this method

    void Serr() {
        // Indicate the input was rejected
        input_read = 0;
    }

public:

    Automaton(TokenType type) { this->type = type; }

    virtual ~Automaton() = default;

    unsigned int Start(const std::string& input) {
        newLines = 0;
        input_read = 0;
        index = 0;
        this->input = input;
        S0();
        return input_read;
    }


    TokenType GetTokenType() const { return type; }

    unsigned int NewLinesRead() const { return newLines; }
};

#endif // AUTOMATON_H

