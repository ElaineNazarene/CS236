#ifndef LEXER_H
#define LEXER_H

#include <vector>
#include "Automaton.h"
#include "Token.h"

using namespace std;

class Lexer {

private:
    vector<Token *> tokens;
    vector<Automaton *> automata;
    string input;

    void CreateAutomata();

public:

    vector <Token*> getTokens(){
        vector <Token*> outputToken;
        for(unsigned int i = 0; i < tokens.size(); i++){
            if(tokens.at(i)->getType() != TokenType::COMMENT){
                outputToken.push_back(tokens.at(i));
            }
        }
        return outputToken;
    }
    Lexer(std::string &input);

    ~Lexer();

    void totalTokens();

    void Run();

    void RunAutomata(string &inputString, unsigned int &lineNumber);

    void AddToken(Token *pToken);

    static void TrimWhitespace(string &inputString, unsigned int &lineNumber);

    static void RaceAutomaton(Automaton *automaton, Automaton *&maxAutomaton, const string &inputString,
                       unsigned int &maxRead);
};

#endif // LEXER_H

