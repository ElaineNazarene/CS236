#ifndef PARSER_H
#define PARSER_H

#include "DatalogProgram.h"
#include "Token.h"
#include <vector>


class Parser {
private:
    unsigned int currIndex = 0;
    std::vector<Token *> tokens;
    DatalogProgram program;
    void advance() {
        currIndex+=1;
    }
    Token* getCurrToken(){
        return tokens.at(currIndex);
    }
    void error() {
        throw getCurrToken();
    }
    bool check(TokenType expected){
        if (expected == getCurrToken()->getType()){
            return true;
        }
        else{
            return false;
        }
    }

    void match(TokenType expected){
        if(check(expected)){
            advance();
        }
        else {
            error();
        }
    }

    string getdescription(){
        return getCurrToken()->getDescription();
    }

    void ParseDatalogProgram();
    
    void ParseSchemeList();
    void ParseFactList();
    void ParseRuleList();
    void ParseQueryList();
    
    void ParseScheme();
    void ParseFact();
    void ParseRule();
    void ParseQuery();

    void ParseHeadPredicate(Predicate &newHead);
    void ParsePredicate(Predicate &newParsePredicate);

    void ParsePredicateList(Rule &newRule);
    void ParseParameterList(Predicate &newParsePredicate);
    void ParseStringList(Predicate &newFact);
    void ParseIdList(Predicate &newScheme);
    void ParseParameter(Predicate &newParsePredicate);

public:
    void Parse(std::vector <Token *> tokens);
    DatalogProgram ReturnDatalogProgram();

};


#endif 
