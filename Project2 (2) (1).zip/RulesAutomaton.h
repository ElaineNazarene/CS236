#ifndef RULES_AUTOMATON_H
#define RULES_AUTOMATON_H

#include "Automaton.h"

class RulesAutomaton : public Automaton {
public:
    RulesAutomaton() : Automaton(TokenType::RULES) {}  // Call the base constructor

    void S0();
    void S1(const std::string& inputString);
    void S2(const std::string& inputString);
    void S3(const std::string& inputString);
    void S4(const std::string& inputString);
};

#endif // RULES_AUTOMATON_H


