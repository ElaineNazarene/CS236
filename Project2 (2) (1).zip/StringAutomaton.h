#ifndef STRING_AUTOMATON
#define STRING_AUTOMATON

#include "Automaton.h"
#include <iostream>

class StringAutomaton : public Automaton {
public:
    StringAutomaton() : Automaton(TokenType::STRING) {}  // Call the base constructor

    void S0();
    void S1(const std::string& inputString);
    void S2(const std::string& inputString);
};

 

#endif // ID_AUTOMATON