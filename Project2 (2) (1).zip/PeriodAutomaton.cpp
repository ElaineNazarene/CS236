#include "PeriodAutomaton.h"

void PeriodAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('.')) {
        Accept();
    } 
}