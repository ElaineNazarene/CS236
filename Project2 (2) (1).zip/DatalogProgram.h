#ifndef DATALOGPROGRAM_H
#define DATALOGPROGRAM_H
#include "Rule.h"
#include <set>
using namespace std;


class DatalogProgram {
private:
    vector<Predicate> schemes;
    vector<Predicate> queries;
    vector<Predicate> facts;
    vector<Rule> rules;
    set <string> domain;

public:

void addString(string value){
    domain.insert(value);
}

void addScheme(Predicate &newScheme){
    schemes.push_back(newScheme);
}

void addRules(Rule &newRules){
    rules.push_back(newRules);
}
void addQueries(Predicate &newQueries){
    queries.push_back(newQueries);
}
void addFacts(Predicate &newFacts){
    facts.push_back(newFacts);
}
    vector <Predicate> getSchemes()
    {
        return this->schemes;
    }


    void setSchemes(vector <Predicate> schemes)
    {
        this->schemes = schemes;
    }

    vector<Predicate> getQueries()
    {
        return this->queries;
    }


    void setQueries(vector <Predicate> queries)
    {
        this->queries = queries;
    }

    vector<Predicate> getFacts()
    {
        return this->facts;
    }


    void setFacts(vector <Predicate> facts)
    {
        this->facts = facts;
    }

    vector<Rule> getRules()
    {
        return this->rules;
    }


    void setRules(vector <Rule> rules)
    {
        this->rules = rules;
    }

string toString() {

    stringstream out;
    // Printing the schemes vector
    std::cout << "Schemes(" << schemes.size() << "):" << endl;
    for (long unsigned int i=0; i < schemes.size(); i++) {
        std::cout << "  " << schemes.at(i).toString() << endl;
    }

    // Printing the facts vector
    std::cout << "Facts(" << facts.size() << "):" << endl;
    for (long unsigned int i=0; i < facts.size(); i++) {
        std::cout << "  " << facts.at(i).toString() << "." << endl;
    }

    // Printing the rules vector
    std::cout << "Rules(" << rules.size() << "):" << endl;
    for (long unsigned int i=0; i < rules.size(); i++) {
        std::cout << "  " << rules.at(i).toString() << endl;
    }

    // Printing the queries vector
    std::cout << "Queries(" << queries.size() << "):" << endl;
    for (long unsigned int i=0; i < queries.size(); i++) {
        std::cout << "  " << queries.at(i).toString() << "?" << endl;
    }

    std::cout << "Domain(" << domain.size() << "):" << endl;
    for(string value : domain) {
        std::cout << "  " << value << endl;
    }

    return out.str();
}

};

#endif