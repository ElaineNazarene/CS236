#ifndef LEXER_H
#define LEXER_H
#pragma once
#include <fstream>
#include <iostream>
#include <list>
#include <vector>
#include "Automaton.h"
#include "Token.h"


#include "ColonAutomaton.h"
#include "ColonDashAutomaton.h"
#include "PeriodAutomaton.h"
#include "QueriesAutomaton.h"
#include "End_Of_FileAutomaton.h"
#include "AddAutomaton.h"
#include "CommaAutomaton.h"
#include "Left_ParenAutomaton.h"
#include "MultiplyAutomaton.h"
#include "PeriodAutomaton.h"
#include "Q_MarkAutomaton.h"
#include "Right_ParenAutomata.h"
#include "FactsAutomaton.h"
#include "IDAutomaton.h"
#include "CommentAutomaton.h"
#include "RulesAutomaton.h"
#include "SchemesAutomaton.h"
#include "StringAutomaton.h"

using namespace std;

class Lexer
{
private:
    std::vector<Automaton*> automata;
    std::vector<Token*> tokens;
  

    Token *newToken;
    void CreateAutomata();
    Automaton *maxAutomaton;
public:
    Lexer(); 
    ~Lexer();
    void Run(string& input); 


    string printTokens(); 

 
    friend ostream& operator<<(ostream& os, Lexer& myLexer){
        os << myLexer.printTokens();
        return os;
    }

    vector<Token*> getTokens();
  

};

#endif // LEXER_H
