#include "ColonDashAutomaton.h"

void ColonDashAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    } else if (Match(':')) {
        Accept();
        S1(input);
    }
}

void ColonDashAutomaton::S1(const std::string &input) {
    if (Match('-')) {
        Accept();
    }
}