

#ifndef RIGHT_PARENAUTOMATA_H
#define RIGHT_PARENAUTOMATA_H


#include "Automaton.h"

class Right_ParenAutomaton : public Automaton
{
public:
    Right_ParenAutomaton() : Automaton(TokenType::RIGHT_PAREN) {}  
    void S0(const std::string& input);
};

#endif // RIGHT_PARENAUTOMATA_H