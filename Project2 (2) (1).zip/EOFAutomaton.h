#ifndef ENDFILEAUTOMATON_H
#define ENDFILEAUTOMATON_H

#include "Automaton.h"

class EOFAutomaton : public Automaton {
public:
    EOFAutomaton() : Automaton(TokenType::ENDFILE) {}  // Call the base constructor

    void S0() {
        if (EndOfFile()) {
            input_read++;
            return;
        } else {
            Serr();
        }
    }
};

#endif // ENDFILEAUTOMATON_H

