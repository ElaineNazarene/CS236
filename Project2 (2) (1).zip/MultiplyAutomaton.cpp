#include "MultiplyAutomaton.h"

void MultiplyAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('*')) {
        Accept();
    } 
}