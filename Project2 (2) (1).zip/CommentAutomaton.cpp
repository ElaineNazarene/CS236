#include "CommentAutomaton.h"

#include <iostream>
#include <sstream>

using namespace std;

void CommentAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    } else if (Match('#')) {
        Accept();
        S1(input);
    } else
        Serr();
}

void CommentAutomaton::S1(const std::string &input) {
    if (Match('|')) {
        Accept();
        S3(input);
    } else if (Match('\n')) {
        return;
    } else if (!Match('\n')) {
        Accept();
        S2(input);
    } else Serr();
}

void CommentAutomaton::S2(const std::string &input) {
    if (EndOfFile()) {
        return;
    }else if (Match('\n')) {
        return;
    }
    else if (!Match('\n')) {
        Accept();
        S2(input);
    }
}

void CommentAutomaton::S3(const std::string &input) {
    if (EndOfFile()) {
        type = TokenType::UNDEFINED;
        return;
    } else if (Match('|')) {
        Accept();
        S4(input);
    } else if (!Match('|')  ) {
        Accept();
        S3(input);
    }
}

void CommentAutomaton::S4(const std::string &input) {
    if (EndOfFile()) {
        type = TokenType::UNDEFINED;
        return;
    } else if (Match('#')) {
        Accept();
        return;
    } else {
        Accept();
        S3(input);
    }
}