#ifndef AUTOMATON_H
#define AUTOMATON_H
#include "Token.h"



class Automaton
{
protected:

    size_t index = 0;
    int newLines = 0; 
    TokenType type; 


public:
    int inputRead = 0; 
    Automaton() : Automaton(TokenType::UNDEFINED) {}

    Automaton(TokenType type) { this->type = type; } 

    virtual ~Automaton() = default;


    int Start(const std::string& input) {
        newLines = 0; 
        inputRead = 0; 
        index = 0; 
        S0(input);
        return inputRead; 
    }


    virtual void S0(const std::string& input) = 0;


    Token* CreateToken(std::string input, int lineNumber) {
        return new Token(type, input, lineNumber); }

    int NewLinesRead() const { return newLines; }

    void Serr() {
        inputRead = 0; 
    }


    bool endFlag = false;
    bool hasMultiline = false;
    int multilineInc = 0;


    void Continue(){
        index++;
        inputRead++;
    }
};

#endif // AUTOMATON_H

