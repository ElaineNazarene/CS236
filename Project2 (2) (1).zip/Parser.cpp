#include <iostream>
#include <utility>
#include "Parser.h"
#include "Token.h"
#include "DatalogProgram.h"


void Parser::Parse(std::vector <Token *> tokens){
    this->tokens = tokens;
    currIndex = 0;
    try{
        ParseDatalogProgram();
        std::cout<< "Success!" << std::endl;
        std::cout<< program.toString();
    }
    catch(Token* errorToken){
        std::cout<< "Failure!" << std::endl;
        std::cout << errorToken->toString();
    }  
}

DatalogProgram Parser::ReturnDatalogProgram(){
    return program;
}

void Parser::ParseDatalogProgram(){
    //SCHEMES COLON scheme schemeList FACTS COLON factList 
    //RULES COLON ruleList QUERIES COLON query queryList EOF

    match(TokenType::SCHEMES);
    match(TokenType::COLON);
    ParseScheme();
    ParseSchemeList();
    match(TokenType::FACTS);
    match(TokenType::COLON);
    ParseFactList();
    match(TokenType::RULES);
    match(TokenType::COLON);
    ParseRuleList();
    match(TokenType::QUERIES);
    match(TokenType::COLON);
    ParseQuery();
    ParseQueryList();
    match(TokenType::ENDFILE);

}

void Parser::ParseSchemeList(){
    //scheme schemeList | lambda
    if(check(TokenType::ID)) {
        ParseScheme();
       ParseSchemeList();
    }
    else{
        //Lambda
    }

}
void Parser::ParseFactList(){
    //fact factList | lambda
    if(check(TokenType::ID)) {
        ParseFact();
       ParseFactList();
    }
    else{
        //Lambda
    }
   
}
void Parser::ParseRuleList(){
    //	rule ruleList | lambda
    if(check(TokenType::ID)) {
        ParseRule();
       ParseRuleList();
    }
    else{
        //Lambda
    }
    
}
void Parser::ParseQueryList(){
    //query queryList | lambda
    if(check(TokenType::ID)) {
        ParseQuery();
       ParseQueryList();
    }
    else{
        //Lambda
    }
    
}


void Parser::ParseScheme(){
    //scheme   	-> 	ID LEFT_PAREN ID idList RIGHT_PAREN
    
    Predicate newScheme;
    newScheme.setName(getdescription());
    match(TokenType::ID);
    match(TokenType::LEFT_PAREN);
    newScheme.AddValue(getdescription());
    match(TokenType::ID);
    ParseIdList(newScheme);
    match(TokenType::RIGHT_PAREN);
    program.addScheme(newScheme);


}
void Parser::ParseFact(){
    //ID LEFT_PAREN STRING stringList RIGHT_PAREN PERIOD

    Predicate newFact;
    newFact.setName(getdescription());
    match(TokenType::ID);
    match(TokenType::LEFT_PAREN);
    newFact.AddValue(getdescription());
    program.addString(getdescription());
    match(TokenType::STRING);
    ParseStringList(newFact);
    match(TokenType::RIGHT_PAREN);
    match(TokenType::PERIOD);
    program.addFacts(newFact);

}
    

void Parser::ParseRule(){
    //headPredicate COLON_DASH predicate predicateList PERIOD
    Rule newRule;
    Predicate newHead;
    Predicate firstBody;
    ParseHeadPredicate(newHead);
    newRule.setheadPredicate(newHead);
    match(TokenType::COLON_DASH);
    ParsePredicate(firstBody);
    newRule.AddBodyPredicate(firstBody);
    ParsePredicateList(newRule);
    match(TokenType::PERIOD);
    program.addRules(newRule);

}
void Parser::ParseQuery(){
    //predicate Q_MARK
    Predicate newQuery;
    ParsePredicate(newQuery);
    match(TokenType::QUESTION);
    program.addQueries(newQuery);
   
}

void Parser::ParseHeadPredicate(Predicate &newHead){
    newHead.setName(getdescription());
    match(TokenType::ID);
    match(TokenType::LEFT_PAREN);
    newHead.AddValue(getdescription());
    match(TokenType::ID);
    ParseIdList(newHead);
    match(TokenType::RIGHT_PAREN);
}

void Parser::ParsePredicate(Predicate &newParsePredicate){
    //Predicate newParsePredicate;
    newParsePredicate.setName(getdescription());
    match(TokenType::ID);
    match(TokenType::LEFT_PAREN);
    ParseParameter(newParsePredicate);
    ParseParameterList(newParsePredicate);
    match(TokenType::RIGHT_PAREN);
}

void Parser::ParsePredicateList(Rule &newRule){
    if(check(TokenType::COMMA)){
        match(TokenType::COMMA);
        Predicate newPredicate;
        ParsePredicate(newPredicate);
        newRule.AddBodyPredicate(newPredicate);
        ParsePredicateList(newRule);
    }
    else{
        //Lambda
    }
}

void Parser::ParseParameterList(Predicate &newParsePredicate){
    if(check(TokenType::COMMA)){
        match(TokenType::COMMA);
        ParseParameter(newParsePredicate);
        ParseParameterList(newParsePredicate);
    }
    else {
        //Lambda
    }
}

void Parser::ParseStringList(Predicate &newFact){
    //COMMA STRING stringList | lambda
    if(check(TokenType::COMMA)){
        //then COMMA ID idList
        match(TokenType::COMMA);
        newFact.AddValue(getdescription());
        program.addString(getdescription());
        match(TokenType::STRING);
        ParseStringList(newFact);
    }
    else {
        //Lambda
    }
};

void Parser::ParseIdList(Predicate &newScheme){
//idList  	-> 	COMMA ID idList | lambda
    if(check(TokenType::COMMA)){
        //then COMMA ID idList
        match(TokenType::COMMA);
        newScheme.AddValue(getdescription());
        match(TokenType::ID);
        ParseIdList(newScheme);
    }
    
    else{
        //Lambda -- basically nothing
    }
}

void Parser::ParseParameter(Predicate &newParsePredicate){
    newParsePredicate.AddValue(getdescription());
    if(check(TokenType::STRING)){
        match(TokenType::STRING);
    }
    else {
        match(TokenType::ID);
    }
}
