#include "AddAutomaton.h"

void AddAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('+')) {
        Accept();
    } 
}