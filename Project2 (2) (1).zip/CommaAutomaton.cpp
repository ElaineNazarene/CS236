#include "CommaAutomaton.h"

void CommaAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match(',')) {
        Accept();
    }
}
