

#ifndef COMMENTAUTOMATON_H
#define COMMENTAUTOMATON_H

#include "Automaton.h"
using namespace std;
class CommentAutomaton: public Automaton{

public:
    CommentAutomaton() : Automaton(TokenType::COMMENT){} 

    void S0(const string& input){
        multilineInc = 0; 

        if (input.at(index) == '#') { 
            Continue(); 
            S1(input); 
        }
    }

    void S1(const string& input){
        if (input.at(index) != '|') { 
            Continue(); 
            S2(input); 
        } else if (input.at(index) == '|') { 
            hasMultiline = true; 
            Continue(); 
            S3(input); 
        }
    }

    void S2(const std::string& input) { 
        if (input.at(index) != '\n') { 
            Continue();
            S2(input); 
        } else {
            return;
        }
    }

    void S3(const std::string& input) {
        size_t sizeOfComment = input.size();
        if (index >= sizeOfComment) { 
            endFlag = true;
            return;
           
        } else if (input.at(index) != '|') { 
            
            if (input[inputRead] == '\n') { 
                multilineInc++; 
            }
            Continue(); 
            S3(input); 
        } else if (input.at(index) == '|') { 
            Continue(); 
            S4(input); 
        }
    }

    void S4(const std::string& input) {
        if (input.at(index) == '#') { 
            Continue();
            return; 
        } else if (input.at(index) == '|') {
            Continue();
            S3(input);
        }else {
            if (input[inputRead] == '\n') {
                S3(input);
            }

            endFlag = true;
            return;
        }
    }
};


#endif //COMMENTAUTOMATON_H
