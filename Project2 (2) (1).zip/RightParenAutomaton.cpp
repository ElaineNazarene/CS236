#include "RightParenAutomaton.h"

void RightParenAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match(')')) {
        Accept();
    } 
}
