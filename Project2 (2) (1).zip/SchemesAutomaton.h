#ifndef SCHEMES_AUTOMATON_H
#define SCHEMES_AUTOMATON_H

#include "Automaton.h"

class SchemesAutomaton : public Automaton {
public:
    SchemesAutomaton() : Automaton(TokenType::SCHEMES) {}  // Call the base constructor

    void S0();
    void S1(const std::string& inputString);
    void S2(const std::string& inputString);
    void S3(const std::string& inputString);
    void S4(const std::string& inputString);
    void S5(const std::string& inputString);
    void S6(const std::string& inputString);
};

#endif // SCHEMES_AUTOMATON_H


