#ifndef PARAMETER_H
#define PARAMETER_H
#include <vector>
#include <string>

using namespace std;


class Parameter{
private:
    string par_id;

public:
  
    void Set_ID(string ID){
        par_id = ID;
    }


    string Get_ID(){ 
        return par_id;
   
    }


    bool isConstant(){
        return (par_id.at(0) == '\'') && (par_id.at(par_id.size() - 1) == '\'');
    }


    string toString() {
        return par_id;
    }
};
#endif //PARAMETER_H
