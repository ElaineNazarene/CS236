
#include "Lexer.h"

using namespace std;


Lexer::Lexer() {
    CreateAutomata(); 
}


Lexer::~Lexer() {
 
    for (size_t i = 0; i < tokens.size(); i++) {
        delete tokens.at(i); 
    }
    tokens.clear();
  
    for (size_t i = 0; i < automata.size(); i++) {
        delete automata.at(i);
    }
    automata.clear();
}


void Lexer::CreateAutomata() {
    automata.push_back(new ColonAutomaton());
    automata.push_back(new ColonDashAutomaton());
    automata.push_back(new AddAutomaton());
    automata.push_back(new CommaAutomaton());
    automata.push_back(new Left_ParenAutomaton());
    automata.push_back(new MultiplyAutomaton());
    automata.push_back(new PeriodAutomaton());
    automata.push_back(new Q_MarkAutomaton());
    automata.push_back(new Right_ParenAutomaton());
    automata.push_back(new FactsAutomaton());
    automata.push_back(new QueriesAutomaton());
    automata.push_back(new RulesAutomaton());
    automata.push_back(new SchemesAutomaton());
    automata.push_back(new IdAutomaton()); 
    automata.push_back(new StringAutomaton());
    automata.push_back(new CommentAutomaton());
    automata.push_back(new EOFAutomaton());
}

void Lexer::Run(std::string& input) {
    int lineNum = 1;

    if (input.empty()) {
        newToken = new Token(TokenType::END_OF_FILE, "", lineNum);
        tokens.push_back(newToken);
        return;
    }


    while (input.size() > 0) {
        int maxRead = 0;
        maxAutomaton = automata.at(0);


       
        while (isspace(input.at(0))) { 
            if (input.at(0) == '\n') { 
                lineNum++; 
            }
            input.erase(0,1); 


            if (input.empty()) { 
                newToken = new Token(TokenType::END_OF_FILE, "", lineNum);
                tokens.push_back(newToken);
                return;
            }
        }


        for (unsigned int i = 0; i < automata.size(); i++) {  
            int inputRead = automata.at(i)->Start(input); 


            if (inputRead > maxRead) { 
                maxRead = inputRead;
                maxAutomaton = automata.at(i);
            }
        }


        if (maxAutomaton->endFlag == true) {
            maxRead += maxAutomaton->inputRead; 
           
            newToken = new Token(TokenType::UNDEFINED, input.substr(0, maxRead), lineNum);
            tokens.push_back(newToken);
   
            if (maxAutomaton->hasMultiline) {
                lineNum += maxAutomaton->multilineInc;
            }
            newToken = new Token(TokenType::END_OF_FILE, "", lineNum);
            tokens.push_back(newToken);
            return;
        }

  
        if (maxRead > 0) {
            string currLine = input.substr(0, maxRead);
            newToken = maxAutomaton->CreateToken(currLine, lineNum);
         
            lineNum += maxAutomaton->NewLinesRead();
        } else {
            maxRead = 1;
            string currLine = input.substr(0, maxRead);
          
            newToken = new Token(TokenType::UNDEFINED, currLine, lineNum);
        }
        if (maxAutomaton->hasMultiline) {
            lineNum += maxAutomaton->multilineInc;
        }

     
        tokens.push_back(newToken);
        input.erase(0, maxRead);
    }
}


string Lexer::printTokens(){
    ostringstream save;
    string output= ""; 

    int totalNumOfTokens = tokens.size();

    for (size_t i = 0; i < tokens.size(); i++){
        save << tokens.at(i)->toString();
    }

    save << "Total Tokens = " << totalNumOfTokens;
    output = save.str();
    return output;
}


vector<Token*>Lexer::getTokens() {
    return tokens;
}


