#ifndef ID_AUTOMATON
#define ID_AUTOMATON

#include "Automaton.h"


class IDAutomaton : public Automaton {
public:
    IDAutomaton() : Automaton(TokenType::ID) {}  // Call the base constructor

    void S0();
    void S1(const std::string& inputString);
};

#endif // ID_AUTOMATON