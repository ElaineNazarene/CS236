#ifndef PARSER_H
#define PARSER_H

#include <vector>
#include <set>

#include "Predicate.h"
#include "Rule.h"
#include "Token.h"
#include "datalogProgram.h"
#include "Lexer.h"
using namespace std;

class Parser {
private:

    vector<Token*> tokens;
    DatalogProgram program;


    size_t position = 0;

public:
 
    Parser(const vector<Token*> t){
        for (auto i : t){
            tokens.push_back(i);
        }
    }


    void match(TokenType t){
  
        if (position >= this->tokens.size()) {
            return;
        }
        if (tokens.at(position)->getTokenType() == TokenType::END_OF_FILE) {
            return;
        }

   
        if (t == tokens.at(position)->getTokenType()) {
            position++;
            Skip_Comments();
      
        } else {
            throw(tokens[position]);
        }
    }


    void Skip_Comments(){
        if (tokens.at(position)->getTokenType() == TokenType::COMMENT) {
            position++;
            Skip_Comments(); 
        }
    }

    DatalogProgram Parse(){
        datalogProgram();
        return program;
    }

   
    void datalogProgram(){
        Skip_Comments();
        match(TokenType::SCHEMES); //SCHEMES
        match(TokenType::COLON); //COLON
        Parse_Scheme(); //scheme
        Parse_SchemeList(); //schemeList
        match(TokenType::FACTS); //FACTS
        match(TokenType::COLON); //COLON
        Parse_FactList(); //factList
        match(TokenType::RULES); //RULES
        match(TokenType::COLON); //COLON
        Parse_RuleList(); //ruleList
        match(TokenType::QUERIES); //QUERIES
        match(TokenType::COLON); //COLON
        Parse_Query(); //query
        Parse_QueryList(); //queryList
        match(TokenType::END_OF_FILE); //EOF
    }


    void Parse_SchemeList(){

        if (tokens.at(position)->getTokenType() == TokenType::ID) {
            Parse_Scheme(); 
            Parse_SchemeList(); 
        }
       
    }


    void Parse_FactList(){
        if (tokens.at(position)->getTokenType() == TokenType::ID) {
            Parse_Fact();
            Parse_FactList(); 
        }
    }


    void Parse_RuleList(){
        if (tokens.at(position)->getTokenType() == TokenType::ID) {
            Parse_Rule();
            Parse_RuleList();
        }
    }


    void Parse_QueryList(){
        if (tokens.at(position)->getTokenType() == TokenType::ID){
            Parse_Query(); 
            Parse_QueryList(); 
        }
    }


    void Parse_Scheme(){
        Predicate scheme;
        Parameter parameter;

     
        match(TokenType::ID);
        scheme.Set_ID(tokens.at(position - 1)->getTokenDescription());


        match(TokenType::LEFT_PAREN);

  
        match(TokenType::ID);

        parameter.Set_ID(tokens.at(position - 1)->getTokenDescription());
        scheme.Add_Parameter(parameter);


        Parse_IdList(scheme);


        match(TokenType::RIGHT_PAREN);


        program.push_Schemes(scheme);

    }

    
    void Parse_Fact(){
        Predicate fact;
        Parameter parameter;

     
        match(TokenType::ID);
        fact.Set_ID(tokens.at(position-1)->getTokenDescription());

     
        match(TokenType::LEFT_PAREN);


        match(TokenType::STRING);
        program.push_Domain(tokens.at(position-1)->getTokenDescription());

        parameter.Set_ID(tokens.at(position-1)->getTokenDescription());
        fact.Add_Parameter(parameter);

 
        Parse_StringList(fact);


        match(TokenType::RIGHT_PAREN);


        match(TokenType::PERIOD);

       
        program.push_Facts(fact);
    }

 
    void Parse_Rule(){
        Predicate ruleHead;
        Predicate rules;
        Rule rule;

   
        headPredicate(ruleHead);

        rule.set_PredicateHead(ruleHead);


        match(TokenType::COLON_DASH);

       
        Parse_Predicate(rules);

        rule.push_Predicate(rules);


        Parse_PredicateList(rule);


        match(TokenType::PERIOD);


        program.push_Rules(rule);
    }

 
    void Parse_Query(){
        Predicate query;

  
        Parse_Predicate(query);

   
        match(TokenType::Q_MARK);

        program.push_Queries(query);
    }

    void headPredicate(Predicate& predicate){
        Parameter param;

 
        match(TokenType::ID);
        predicate.Set_ID(tokens.at(position-1)->getTokenDescription());


        match(TokenType::LEFT_PAREN);


        match(TokenType::ID);

        param.Set_ID(tokens.at(position-1)->getTokenDescription());
        predicate.Add_Parameter(param);

  
        Parse_IdList(predicate);


        match(TokenType::RIGHT_PAREN);
    }

  
    void Parse_Predicate(Predicate& predicate){

        match(TokenType::ID);

        predicate.Set_ID(tokens.at(position-1)->getTokenDescription());

     
        match(TokenType::LEFT_PAREN);


        Parse_Parameter(predicate);


        Parse_ParameterList(predicate);


        match(TokenType::RIGHT_PAREN);
    }


    void Parse_PredicateList(Rule& rule){
       
        if (tokens.at(position)->getTokenType() == TokenType::COMMA){
            Predicate p;

       
            match(TokenType::COMMA);

         
            Parse_Predicate(p);

      
            rule.push_Predicate(p);

      
            Parse_PredicateList(rule);
        }
    }

 
    void Parse_ParameterList(Predicate& predicate){
        if (tokens.at(position)->getTokenType() == TokenType::COMMA) {
            match(TokenType::COMMA);

            Parse_Parameter(predicate);
            Parse_ParameterList(predicate);
        }
    }


    void Parse_StringList(Predicate& predicate){
        if (tokens.at(position)->getTokenType() == TokenType::COMMA) {
            Parameter p;

       
            match(TokenType::COMMA);

   
            match(TokenType::STRING);

    
            program.push_Domain(tokens.at(position-1)->getTokenDescription());
            p.Set_ID(tokens.at(position-1)->getTokenDescription());
            predicate.Add_Parameter(p);

            Parse_StringList(predicate);
        }
    }


    void Parse_IdList(Predicate& predicate){
        if (tokens.at(position)->getTokenType() == TokenType::COMMA) {
            Parameter p;

          
            match(TokenType::COMMA);

     
            match(TokenType::ID);

            p.Set_ID(tokens.at(position - 1)->getTokenDescription());
            predicate.Add_Parameter(p);

            Parse_IdList(predicate);
        }
    }


    void Parse_Parameter(Predicate& predicate){

        if (tokens.at(position)->getTokenType() == TokenType::STRING) {
         
            match(TokenType::STRING);
            
        } else if (tokens.at(position)->getTokenType() == TokenType::ID) {
            match(TokenType::ID);
        }


        Parameter parameter;

        parameter.Set_ID(tokens.at(position-1)->getTokenDescription());
        predicate.Add_Parameter(parameter);
    }

};

#endif //PARSER_H
