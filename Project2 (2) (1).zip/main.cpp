#include "Lexer.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include "Parser.h"
 
int main(int argc, char** argv) {



    std::ifstream input(argv[1]);
    std::stringstream in;


    input.open(argv[1]);
    in << input.rdbuf();
    input.close();

    std::string file = in.str();

//    std::ifstream ifs(argv[1]);
//    string file, line;
//    while(getline(ifs,line))
//    {
//        file+= line + '\n';
//    }

    auto lexer = new Lexer(file);
    lexer->Run();
    //lexer->totalTokens();
    
    Parser parser;
    parser.Parse(lexer->getTokens());
    delete lexer;

    return 0;
}