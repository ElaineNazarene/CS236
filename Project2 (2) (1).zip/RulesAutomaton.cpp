#include "RulesAutomaton.h"

void RulesAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('R')) {
        Accept();
        S1(input);
    } else {
        Serr();
    }
}

void RulesAutomaton::S1(const std::string& input) {
    if (Match('u')) {
        Accept();
        S2(input);
    } else {
        Serr();
    }
}

void RulesAutomaton::S2(const std::string& input) {
    if (Match('l')) {
        Accept();
        S3(input);
    } else {
        Serr();
    }
}

void RulesAutomaton::S3(const std::string& input) {
    if (Match('e')) {
        Accept();
        S4(input);
    } else {
        Serr();
    }
}

void RulesAutomaton::S4(const std::string& input) {
    if (Match('s')) {
        Accept();
    } else {
        Serr();
    }
}
