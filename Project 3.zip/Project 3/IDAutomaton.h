
#ifndef IDAUTOMATON_H
#define IDAUTOMATON_H

#include "Automaton.h"
#include <cctype>
using namespace std;


class IdAutomaton : public Automaton {
public:
    IdAutomaton() : Automaton(TokenType::ID) {
        type = TokenType::ID;
    }
    void S0(const string& input) {
        if (isalpha(input[index])) {
            Continue();
            S1(input);
        }
    }

    void S1(const string& input) {
        if(isalpha(input[index])) {
            Continue();
            S1(input);
        } else if (isdigit(input[index])){
            Continue();
            S1(input);
        }
    }
};

#endif //IDAUTOMATON_H
