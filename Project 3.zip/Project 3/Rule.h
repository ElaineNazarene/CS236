#ifndef RULE_H
#define RULE_H

#include <vector>
#include <string>
#include <sstream>

#include "Predicate.h"
using namespace std;

class Rule{
private:
 
    vector<Predicate> predicates;
    Predicate head;

public:
    void set_PredicateHead(Predicate p) {
        head = p;
    }


    void push_Predicate(Predicate p){
        predicates.push_back(p);
    }

   
    string toString() {
        string pad = "";
        stringstream o;

        o << head.toString() << " :- "; 

        for (Predicate currPred : predicates) {
            o << pad << currPred.toString();
            pad = ",";
        }

        return o.str();
    }
};
#endif //RULE_H
