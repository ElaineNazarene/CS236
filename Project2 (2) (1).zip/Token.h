#ifndef TOKEN_H
#define TOKEN_H
#include <string>

enum TokenType {
    COMMA, //0
    COLON, // 1
    COLON_DASH,
    PERIOD,
    MULTIPLY,
    QUESTION,
    ADD,
    RIGHT_PAREN,
    LEFT_PAREN,
    SCHEMES,
    FACTS,
    RULES,
    QUERIES,
    ID,
    COMMENT,
    STRING,
    UNDEFINED, 
    ENDFILE
};



class Token {
private:
    unsigned int line;
    TokenType type;
    std::string description;

public:
    int getLine()
    {
        return this->line;
    }


    void setLine(int line)
    {
        this->line = line;
    }


    TokenType getType()
    {
        return this->type;
    }


    void setType(TokenType type)
    {
        this->type = type;
    }


    std::string getDescription()
    {
        return this->description;
    }


    void setDescription(std::string description)
    {
        this->description = description;
    }

    Token(TokenType type, std::string description, unsigned int line);
    std::string toString();
    static std::string ConvertToken(TokenType tokenType);
    
};

#endif // TOKEN_H