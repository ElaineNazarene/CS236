#include "IDAutomaton.h"

void IDAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (isalpha(CurrentLetter())) {
        Accept();
        S1(input);
    } 
}

void IDAutomaton::S1(const std::string& input) {
    if (isalnum(CurrentLetter())) {
        Accept();
        S1(input);
    }
}
