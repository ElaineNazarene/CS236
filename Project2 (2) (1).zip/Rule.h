#ifndef RULE_H
#define RULE_H
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include "Predicate.h"

using namespace std;

class Rule
{
private:
    Predicate headPredicate;
    vector<Predicate> bodyPredicates;

public:
    Predicate getheadPredicate()
    {
        return this->headPredicate;
    }

    void setheadPredicate(Predicate headPredicate)
    {
        this->headPredicate = headPredicate;
    }

    vector<Predicate> getbodyPredicate()
    {
        return this->bodyPredicates;
    }

    void setbodyPredicate(vector<Predicate> bodyPredicate)
    {
        this->bodyPredicates = bodyPredicate;
    }

    void AddBodyPredicate(Predicate value)
    {
        bodyPredicates.push_back(value);
    }

    Rule(){
        
    }

    string toString()
    {
        stringstream ss;

        ss << headPredicate.toString() << " :- ";

        for (unsigned int i = 0; i < bodyPredicates.size() - 1; i++)
        {
            ss << bodyPredicates.at(i).toString() << ", ";
        }
        ss << bodyPredicates.at(bodyPredicates.size() - 1).toString() << ".";
        return ss.str();
    }
};

#endif