#ifndef QUERIES_AUTOMATON_H
#define QUERIES_AUTOMATON_H

#include "Automaton.h"

class QueriesAutomaton : public Automaton {
public:
    QueriesAutomaton() : Automaton(TokenType::QUERIES) {}  // Call the base constructor

    void S0();
    void S1(const std::string& inputString);
    void S2(const std::string& inputString);
    void S3(const std::string& inputString);
    void S4(const std::string& inputString);
    void S5(const std::string& inputString);
    void S6(const std::string& inputString);
};

#endif // QUERIES_AUTOMATON_H


