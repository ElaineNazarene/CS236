#include "LeftParenAutomaton.h"

void LeftParenAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('(')) {
        Accept();
    } 
}
