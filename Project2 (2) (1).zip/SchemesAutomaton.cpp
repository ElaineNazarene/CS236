#include "SchemesAutomaton.h"

void SchemesAutomaton::S0() {
    if (EndOfFile()) {
        Serr();
    }
    else if (Match('S')) {
        Accept();
        S1(input);
    } else {
        Serr();
    }
}

void SchemesAutomaton::S1(const std::string& input) {
    if (Match('c')) {
        Accept();
        S2(input);
    } else {
        Serr();;
    }
}

void SchemesAutomaton::S2(const std::string& input) {
    if (Match('h')) {
        Accept();
        S3(input);
    } else {
        Serr();
    }
}

void SchemesAutomaton::S3(const std::string& input) {
    if (Match('e')) {
        Accept();
        S4(input);
    } else {
        Serr();
    }
}

void SchemesAutomaton::S4(const std::string& input) {
    if (Match('m')) {
        Accept();
        S5(input);
    } else {
        Serr();
    }
}

void SchemesAutomaton::S5(const std::string& input) {
    if (Match('e')) {
        Accept();
        S6(input);
    } else {
        Serr();
    }
}

void SchemesAutomaton::S6(const std::string& input) {
    if (Match('s')) {
        Accept();
    } else {
        Serr();
    }
}
