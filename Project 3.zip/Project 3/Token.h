#ifndef TOKEN_H
#define TOKEN_H
#include <string>

using namespace std;

enum class TokenType {
    COLON,
    COLON_DASH,
   
     COMMA, PERIOD, LEFT_PAREN, RIGHT_PAREN, Q_MARK, ADD, MULTIPLY,
     FACTS,
     SCHEMES,
     RULES,
     QUERIES,
     UNDEFINED,
     COMMENT,
     END_OF_FILE,
     ID,
     STRING
};

class Token
{
private:

    TokenType type; 
    string description; 
    int lineNum; 

    string tokenName;
public:



    Token(TokenType type, string description, int lineNum);

    string toString() ;
    string TokenConverterToString(TokenType type);


    string getTokenName();

    string getTokenDescription();


    TokenType getTokenType();


};

#endif // TOKEN_H


