
#ifndef PERIODAUTOMATON_H
#define PERIODAUTOMATON_H


#include "Automaton.h"

class PeriodAutomaton : public Automaton {
public:
    PeriodAutomaton() : Automaton(TokenType::PERIOD) {}  

    void S0(const std::string& input){
        if (input[index] == '.') {
            inputRead = 1;
        }
    }
};

#endif //PERIODAUTOMATON_H
