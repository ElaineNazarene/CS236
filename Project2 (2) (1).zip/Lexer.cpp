#include "Lexer.h"
#include "Automata.h"
#include <iostream>

Lexer::Lexer(std::string &input) :input(input) {
    CreateAutomata();
}



Lexer::~Lexer() {

    for (auto token: tokens) {
        delete token;
    }

    tokens.clear();

    for (auto automaton: automata) {
        delete automaton;
    }

    automata.clear();
}

void Lexer::CreateAutomata() {
    automata.push_back(new CommaAutomaton());
    automata.push_back(new PeriodAutomaton());
    automata.push_back(new QuestionAutomaton());
    automata.push_back(new ColonAutomaton());
    automata.push_back(new ColonDashAutomaton());
    automata.push_back(new LeftParenAutomaton());
    automata.push_back(new RightParenAutomaton());
    automata.push_back(new AddAutomaton());
    automata.push_back(new MultiplyAutomaton());
    automata.push_back(new SchemesAutomaton());
    automata.push_back(new FactsAutomaton());
    automata.push_back(new RulesAutomaton());
    automata.push_back(new QueriesAutomaton());
    automata.push_back(new IDAutomaton());
    automata.push_back(new StringAutomaton());
    automata.push_back(new CommentAutomaton());
    automata.push_back(new EOFAutomaton());
    automata.push_back(new UndefinedAutomaton());
}


void Lexer::Run() {
    unsigned int lineNumber = 1;
    string inputToLex = input;
    while (!inputToLex.empty()) {
        RunAutomata(inputToLex, lineNumber);
    }

    AddToken(new Token(TokenType::ENDFILE, "", lineNumber));
}

void Lexer::RunAutomata(string &input, unsigned int &lineNumber) {
    unsigned int maxRead = 0;
    Automaton *maxAutomaton = automata.at(0);

    TrimWhitespace(input, lineNumber);

    for (auto automaton: automata) {
        RaceAutomaton(automaton, maxAutomaton, input, maxRead);
    }

    if (maxAutomaton->GetTokenType() == TokenType::ENDFILE) {
        return;
    }

    string subStr = input.substr(0, maxRead);
    AddToken(new Token(maxAutomaton->GetTokenType(), subStr, lineNumber));

    lineNumber += maxAutomaton->NewLinesRead();

    input = input.substr(maxRead);
}

void
Lexer::RaceAutomaton(Automaton *automaton, Automaton*& maxAutomaton, const string &input, unsigned int &maxRead)
{
    unsigned int input_read = automaton->Start(input);

    if (input_read > maxRead) {
        maxRead = input_read;
        maxAutomaton = automaton;
    }
}

void Lexer::TrimWhitespace(string &input, unsigned int &lineNumber) {
    while (isspace(input.front())) {
        if (input.front() == '\n') {
            lineNumber++;
        }
        input = input.substr(1);
    }
}

void Lexer::totalTokens() {
    for (auto token: tokens) {
        cout << token->toString() << endl;
    }
    std::cout << "Total Tokens = " << tokens.size();
}

void Lexer::AddToken(Token *pToken) {
    tokens.push_back(pToken);
}
